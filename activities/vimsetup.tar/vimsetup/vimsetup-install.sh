#!/bin/bash

echo
/bin/cp -fr .vimrc .gvimrc .vim ~/

echo "Vim installation completed!"
echo

