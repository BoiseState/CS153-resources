#!/bin/bash

/bin/cp -fr .vimrc .gvimrc .vim ~/

